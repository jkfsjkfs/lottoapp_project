export { default as HomeScreen } from './HomeScreen';
export { default as NumeroScreen } from './NumeroScreen';
export { default as DatosScreen } from './DatosScreen';
export { default as ConfirmacionScreen } from './ConfirmacionScreen';
