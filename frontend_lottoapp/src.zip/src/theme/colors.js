export default {
  primary: '#0a84ff',
  text: '#111',
  muted: '#666',
  border: '#ccc',
  background: '#fff'
}
