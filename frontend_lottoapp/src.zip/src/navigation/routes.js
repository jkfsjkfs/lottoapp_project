export const ROUTES = {
  LOGIN: 'Login',
  HOME: 'Home',
  NUMERO: 'Numero',
  DATOS: 'Datos',
  CONFIRMACION: 'Confirmacion',
};
